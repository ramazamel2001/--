package com.android.application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
